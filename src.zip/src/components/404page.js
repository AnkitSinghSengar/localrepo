import React from "react";

function ErrorPage() {
  return (
    <div className="App">
      <h2 style={{ color: "red" }}>404 ! Page Not Found</h2>
    </div>
  );
}

export default ErrorPage;
